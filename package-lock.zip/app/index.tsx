import React from 'react';
import { View, Text } from 'react-native';



export function index() {
  return (
    <View>
        <Text>Sou a index</Text>
    </View>
  );
}

