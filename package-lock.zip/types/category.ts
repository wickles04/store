type Category = {
    id: number,
    title: string,
    cover: string,
}